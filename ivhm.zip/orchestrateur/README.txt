Exemple de lancement : 
python orchestrateur dossierApplication/ tts/tts1.py tts/tts2.py (formalisation ou synthetisation ou mfcc ou dtw ou ranking)

OU

./lancerOrchestrateur.sh
