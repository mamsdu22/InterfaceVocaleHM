from distutils.core import setup

setup(name='speech-features',
      version='0.1',
      description='Python Speech Feature extraction',
      author='James Lyons',
      url='https://github.com/jameslyons/python_speech_features',
      packages=['features'],
    )
