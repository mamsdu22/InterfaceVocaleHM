#!/bin/bash

python orchestrateur.py dossierApplication tts/tts1.py tts/tts2.py formalisation
